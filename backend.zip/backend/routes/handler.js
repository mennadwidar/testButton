const express = require('express');
const res = require('express/lib/response');
const router = express.Router();
let {PythonShell} = require('python-shell')

router.get('/tweets', (req,res) =>{
    const str = [{
        "name": "Menna",
        "msg": "This is my first tweet!",
        "username": "mennaaaaa"
    }];
    res.end(JSON.stringify(str));
});

router.get('/helloWorld', (req,res) =>{
    const str = [{
        "msg": "Hello world"
    }];
    res.end(JSON.stringify(str));
});

router.get('/pyTrial', (req,res) =>{
    PythonShell.run("./script1.py",null,function(err,results){
        console.log(results)
        console.log("Python script finished")
    })
});
/*
router.get('/pyTrial', callName);

function callName(req, res){
var process = spawn('python',["./script.py", req.query.firstname, req.query.lastname]);

process.stdout.on('data',function(data){
    res.send(data.toString());
});

}

const data_to_pass_in = "Send this to python script";

console.log("data sent to python script:", data_to_pass_in);

const python_process = spawner('python',["./script1.py", JSON.stringify(data_to_pass_in)]);

python_process.stdout.on('data',function(data){
    console.log("data received from python script:", data.toString())
});
*/
router.post('/addTweet', (req,res) => {
    res.end('NA');
});

// pythonshell.run("script1.py",null,function(err,results){
//     console.log(results)
//     console.log("Python script finished")
// })

module.exports = router;