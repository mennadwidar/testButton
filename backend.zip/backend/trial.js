let {PythonShell} = require('python-shell')

PythonShell.run("./script1.py",null,function(err,results){
    console.log(results)
    console.log("Python script finished")
})
// const spawner = require('child_process').spawn;

// const data_to_pass_in = "Send this to python script";

// console.log("data sent to python script:", data_to_pass_in);

// const python_process = spawner('python',['./script1.py', data_to_pass_in]);

// python_process.stdout.on('data',(data) => {
//     console.log("data received from python script:", data.toString())
// });


