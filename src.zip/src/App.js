//import logo from './logo.svg';
import './App.css';
import Nav from './components/Nav'
import Home from './components/Home'
import Tweet from './components/Tweet'
import HelloWorld from './components/HelloWorld';
import PyTrial from './components/PyTrial';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';


function App() {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
        <Nav />
        <Routes>
          <Route path="/"  element={<Home/>} />
          <Route path="/helloWorld"  element={<HelloWorld/>} />
          <Route path="/tweets"  element={<Tweet/>} />
          <Route path="/pyTrial"  element={<PyTrial/>} />
        </Routes> 
      </header>
    </div>
    </Router>
  );
}

export default App;
