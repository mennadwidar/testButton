import React, {useEffect, useState} from 'react';
import {Link} from 'react-router-dom';

function PyTrial(){
    useEffect( () => {
        fetchItems();
    }, []);

    const [items, setItems] = useState([]);
    const fetchItems = async() => {
        const data = await fetch('/pyTrial');
        const items = await data.json();
        setItems(items);
    };
    return(
        <section>
            {
                items.map(item => (
                <div>
                </div>
                ))
            }
                  </section>
    );
}

export default PyTrial;