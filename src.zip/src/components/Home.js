import React from 'react';

function Home(){
    return( 
        <section>
            <div class="container-fluid">
                <h1 class="mt-5">Welcome</h1>
                <p>Digital lab</p>
            </div>
        </section>
    );

}

export default Home;